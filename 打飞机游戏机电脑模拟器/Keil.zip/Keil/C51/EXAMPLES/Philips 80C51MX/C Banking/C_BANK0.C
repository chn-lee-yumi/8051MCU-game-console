/*------------------------------------------------------------------------------
C_BANK0.C

Copyright 2000 KEIL Software, Inc.
------------------------------------------------------------------------------*/

#include <stdio.h>

extern void func2(void);

void func0(void) {
  printf("THIS IS A FUNCTION IN BANK 0 \n");
}
