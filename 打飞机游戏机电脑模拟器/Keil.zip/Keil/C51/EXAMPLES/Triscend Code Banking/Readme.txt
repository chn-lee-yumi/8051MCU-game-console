Readme.txt
==========

The files in this directory should be installed respectively as
    %UV2%\C51\INC\Triscend\Readme.txt
    %UV2%\C51\INC\Triscend\TE5_CSOC.H
    %UV2%\C51\INC\Triscend\TE5_CSOC.INC
where %UV2% is the root directory at which Keil uVision2 is installed.

Include the following file for the register definitions of all 
Triscend E5 CSoC devices:
    TE5_CSOC.H:    use with C-51
    TE5_CSOC.INC:  use with A51, with directive NOMOD51 on

